=== CakePHP 5 adapter demo – Demonstration for `CakePHP 5 adapter` ===

Plugin Name:         Gloubi Boulga WP CakePHP 5 Adapter
Plugin URI:          https://github.com/gloubi-boulga-team/gbg-cake-demo
Description:         Embed CakePHP(tm) libraries (ORM, Log, Cache...) into your WP extension
Version:             5.0.0
Stable tag:          5.0.0
Author:              Gloubi Boulga Team
Author URI:          https://github.com/gloubi-boulga-team
License:             MIT
License URI:         https://opensource.org/licenses/mit-license.php
Text Domain:         gbg-cake5
Tested up to:        6.5
Requires at least:   6.2
Requires PHP:        8.1
Domain Path:         /resources/locales

Test "CakePHP 5 adapter" plugin.

Have a good day ☮️ !
